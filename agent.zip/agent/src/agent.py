# src/agent.py
from typing import List
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.memory import ConversationBufferMemory, VectorStoreRetrieverMemory

from config import settings
from llm import make_llm
from tools import TOOLS


def make_memory():
    # Long-term memory (FAISS)
    embeddings = HuggingFaceEmbeddings(model_name=settings.embedding_model)
    try:
        vs = FAISS.load_local(
            settings.memory_store_dir,
            embeddings,
            allow_dangerous_deserialization=True
        )
    except Exception:
        vs = FAISS.from_texts(["System memory initialized."], embedding=embeddings)
        vs.save_local(settings.memory_store_dir)

    retriever = vs.as_retriever(search_kwargs={"k": 4})

    # NOTE: Deprecation warnings are expected with pinned deps
    long_mem = VectorStoreRetrieverMemory(
        retriever=retriever,
        memory_key="history",
    )
    short_mem = ConversationBufferMemory(
        memory_key="chat_history",
        return_messages=True
    )
    return long_mem, short_mem, vs


def make_agent():
    llm = make_llm()
    long_mem, short_mem, memory_store = make_memory()

    # Prepare tool descriptions
    tool_desc = "\n".join(
        f"- {t.name}: {t.description or 'No description'}" for t in TOOLS
    )
    tool_names = ", ".join(t.name for t in TOOLS)

    # ReAct prompt:
    # - {tools}, {tool_names}
    # - chat_history as messages
    # - agent_scratchpad as STRING (important for LangChain 0.2.x ReAct agent)
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system",
                (
                    "You are a senior SRE/Support engineer for a Banking Management System.\n"
                    "Use tools when helpful. Prefer citing error codes and stepwise runbooks.\n"
                    "If the user reports a symptom, retrieve related KB and propose diagnostics & resolution.\n\n"
                    "Available tools:\n{tools}\n\n"
                    "Call tools only by these names: {tool_names}\n\n"
                    "When reasoning or solving a task, follow this format:\n"
                    "Thought: <reasoning about the next step>\n"
                    "Action: <tool name from the list above>\n"
                    "Action Input: <string input to the tool>\n"
                    "Observation: <tool output will appear here>\n"
                    "Repeat Thought/Action... until final answer.\n"
                    "When done, respond with:\n"
                    "Final Answer: <your answer to the user>\n"
                ),
                ),
            MessagesPlaceholder("chat_history"),
            ("human", "{input}"),
            # IMPORTANT: keep agent_scratchpad as a STRING placeholder for this LC version
            ("ai", "{agent_scratchpad}"),
        ]
    ).partial(tools=tool_desc, tool_names=tool_names)

    # Build agent and executor
    agent = create_react_agent(llm=llm, tools=TOOLS, prompt=prompt)

    executor = AgentExecutor(
        agent=agent,
        tools=TOOLS,
        verbose=True,
        memory=short_mem,  # short-term memory for chat history
        handle_parsing_errors=True,
        max_iterations=2
    )

    class AgentWithMemory:
        def __init__(self, exec_, long_term_mem, vs_):
            self.exec = exec_
            self.long_mem = long_term_mem
            self.vs = vs_

        def aask(self, query: str):
            # Do NOT pass agent_scratchpad; AgentExecutor will supply a string
            return self.exec.invoke({"input": query})

        def remember(self, note: str):
            self.vs.add_texts([note])
            self.vs.save_local(settings.memory_store_dir)
            return "Noted."

    return AgentWithMemory(executor, long_mem, memory_store)


if __name__ == "__main__":
    agent = make_agent()
    print(agent.aask("Hello, what can you do?"))
