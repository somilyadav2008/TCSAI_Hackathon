import os
from dataclasses import dataclass

@dataclass
class Settings:
    provider: str = os.getenv("PROVIDER", "ollama")  # 'openai' or 'ollama'
    openai_model: str = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    ollama_model: str = os.getenv("OLLAMA_MODEL", "llama3")
    embedding_model: str = os.getenv("EMBEDDING_MODEL", "sentence-transformers/all-MiniLM-L6-v2")
    kb_store_dir: str = os.getenv("KB_STORE_DIR", ".store/kb_index")
    memory_store_dir: str = os.getenv("MEMORY_STORE_DIR", ".store/memory_index")
    data_dir: str = os.getenv("DATA_DIR", "data")

settings = Settings()
