import os, sys
from agent import make_agent

BANNER = """
==================================================
  Banking Maintenance RAG Agent (LangChain)
  - Tools: retrieve_kb, manual_by_error, filter_logs
  - Memory: short-term + vector long-term
  Type 'remember: <fact>' to store long-term memory.
  Type 'exit' to quit.
==================================================
"""

def main():
    print(BANNER)
    agent = make_agent()
    while True:
        try:
            q = input("You> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break
        if not q:
            continue
        if q.lower() in {"exit", "quit"}:
            print("Bye!")
            break
        if q.lower().startswith("remember:"):
            note = q.split(":", 1)[1].strip()
            print(agent.remember(note))
            continue
        resp = agent.aask(q)
        out = resp.get("output", resp)
        print(f"Agent> {out}\n")

if __name__ == "__main__":
    main()
