from config import settings


def make_llm():
    # Always use Ollama unless explicitly set to OpenAI
    provider = settings.provider.lower().strip()
    if provider == "ollama":
        # LangChain 0.2.x
        from langchain_ollama import ChatOllama
        return ChatOllama(
            model=settings.ollama_model or "llama-3.2-3b-it:latest",
            base_url=getattr(settings, "ollama_base_url", "http://127.0.0.1:11434"),
            temperature=0.2,
        )
    else:
        # Default to Ollama to avoid accidental OpenAI hits
        from langchain_ollama import ChatOllama
        return ChatOllama(
            model="llama-3.2-3b-it:latest",
            base_url="http://127.0.0.1:11434",
            temperature=0.2,
        )
