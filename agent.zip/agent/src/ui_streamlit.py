# src/ui_streamlit.py
import os
import shutil
import traceback
import streamlit as st

from config import settings
from agent import make_agent

st.set_page_config(page_title="Banking Maintenance RAG Agent", page_icon="🛠️", layout="wide")

# ---------- Helpers ----------
def init_session():
    if "agent" not in st.session_state:
        st.session_state.agent = None  # lazy init
    if "chat" not in st.session_state:
        st.session_state.chat = []  # list of dicts: {"role": "user"/"assistant", "content": str}
    if "startup_error" not in st.session_state:
        st.session_state.startup_error = None

def ensure_agent():
    if st.session_state.agent is None:
        try:
            st.session_state.agent = make_agent()
            st.session_state.startup_error = None
        except Exception as e:
            st.session_state.agent = None
            st.session_state.startup_error = f"{e.__class__.__name__}: {e}"

def reset_short_term():
    # Recreate the agent to clear ConversationBufferMemory
    try:
        st.session_state.agent = make_agent()
        st.session_state.chat = []
        st.toast("Short-term memory cleared (session reset).", icon="✅")
    except Exception as e:
        st.session_state.agent = None
        st.session_state.startup_error = f"{e.__class__.__name__}: {e}"
        st.error(f"Failed to reset: {st.session_state.startup_error}")

def clear_vector_memory():
    # Danger: wipes long-term FAISS store
    mem_dir = settings.memory_store_dir
    try:
        if os.path.exists(mem_dir):
            shutil.rmtree(mem_dir)
        # rebuild empty agent vector store
        st.session_state.agent = make_agent()
        st.toast(f"Long-term vector memory cleared: {mem_dir}", icon="🧹")
    except Exception as e:
        st.session_state.agent = None
        st.session_state.startup_error = f"{e.__class__.__name__}: {e}"
        st.error(f"Failed to clear vector memory: {st.session_state.startup_error}")

def add_texts_to_memory(texts):
    try:
        ag = st.session_state.agent
        if ag is None:
            raise RuntimeError("Agent not ready")
        # AgentWithMemory in agent.py keeps 'vs' accessible
        ag.vs.add_texts(texts)
        ag.vs.save_local(settings.memory_store_dir)
        st.toast(f"Added {len(texts)} chunk(s) to long-term memory.", icon="📚")
    except Exception as e:
        st.error(f"Failed to add to memory: {e}")

def vector_count():
    try:
        ag = st.session_state.agent
        if ag is None:
            return 0
        vs = ag.vs
        # FAISS vectorstore exposes index.ntotal
        return int(getattr(vs.index, "ntotal", 0))
    except Exception:
        return 0

# ---------- UI ----------
init_session()

st.title("🛠️ Banking Maintenance RAG Agent")
st.caption("LangChain • ReAct • Tools • Short-term + FAISS long-term memory • Local LLM via Ollama")

with st.sidebar:
    st.subheader("⚙️ Runtime")
    st.write(f"**Provider**: `{settings.provider}`")
    if settings.provider.lower() == "ollama":
        st.write(f"**Model**: `{settings.ollama_model}`")
    elif settings.provider.lower() == "openai":
        st.write(f"**OpenAI Model**: `{settings.openai_model}`")
    st.write(f"**Embedding model**: `{settings.embedding_model}`")
    st.write(f"**Memory dir**: `{settings.memory_store_dir}`")
    st.write(f"**Vector memory size**: `{vector_count()}`")

    st.divider()
    st.subheader("🧠 Memory Controls")
    colA, colB = st.columns(2)
    with colA:
        if st.button("Reset short-term", use_container_width=True):
            reset_short_term()
    with colB:
        if st.button("Clear vector memory", type="primary", use_container_width=True):
                clear_vector_memory()

    st.divider()
    st.subheader("📥 Upload snippets into long-term memory")
    up = st.file_uploader(
        "Upload TXT/LOG/MD/CSV to store as retrievable memory chunks",
        type=["txt", "log", "md", "csv"],
        accept_multiple_files=True
    )
    if up:
        new_texts = []
        for f in up:
            try:
                content = f.read().decode("utf-8", errors="ignore")
                new_texts.append(f"[{f.name}] {content}")
            except Exception as e:
                st.warning(f"{f.name}: {e}")
        if new_texts and st.button(f"Add {len(new_texts)} file(s) to memory"):
            ensure_agent()
            if st.session_state.agent:
                add_texts_to_memory(new_texts)
            else:
                st.error(f"Agent not ready: {st.session_state.startup_error}")

    st.divider()
    st.subheader("📝 Quick Remember")
    memo = st.text_area("Store a fact in long-term memory (FAISS):", placeholder="Example: UAT DB reset requires DBA approval.")
    if st.button("Remember"):
        ensure_agent()
        if st.session_state.agent:
            if memo.strip():
                st.session_state.agent.remember(memo.strip())
                st.success("Noted in FAISS memory.")
            else:
                st.info("Enter something to remember.")
        else:
            st.error(f"Agent not ready: {st.session_state.startup_error}")

# Main chat layout
chat_container = st.container()

with chat_container:
    # Show any startup error prominently
    if st.session_state.startup_error:
        st.error(f"Agent startup error: {st.session_state.startup_error}")

    for msg in st.session_state.chat:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_prompt = st.chat_input("Ask about incidents, errors, logs…")
    if user_prompt:
        st.session_state.chat.append({"role": "user", "content": user_prompt})
        with st.chat_message("user"):
            st.markdown(user_prompt)

        # Call the agent (lazily ensure it's created)
        with st.chat_message("assistant"):
            ensure_agent()
            if not st.session_state.agent:
                st.error(f"Agent failed to start: {st.session_state.startup_error}")
            else:
                with st.spinner("Thinking…"):
                    try:
                        out = st.session_state.agent.aask(user_prompt)
                        # The AgentExecutor returns {"output": "...", ...}
                        answer = out.get("output", str(out))
                        st.markdown(answer)
                        st.session_state.chat.append({"role": "assistant", "content": answer})
                    except Exception as e:
                        st.error(f"Agent error: {e}")
