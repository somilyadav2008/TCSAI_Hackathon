# Banking Maintenance RAG Agent (LangChain)

End-to-end example of a **LangChain AI Agent** with **RAG + Embeddings + Memory**
for a **Banking Management System (BMS)**.

## Features
- Retrieval-Augmented Generation over troubleshooting manuals, logs, and tickets
- Short-term chat memory + long-term vector memory
- Pluggable LLM: **OpenAI** or **Ollama** (local)
- Simple CLI runner

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Configure one of the providers
# OpenAI:
export PROVIDER=openai
export OPENAI_API_KEY=...

# OR Ollama (local model like llama3, qwen, mistral):
export PROVIDER=ollama
export OLLAMA_MODEL=llama3

# Build vector index from data/
python src/build_index.py

# Run the agent
python src/cli.py
```

## Data
- `data/maintenance_logs.csv` — 240 realistic log rows
- `data/sample_issues.csv` — 40 helpdesk-style tickets
- `data/troubleshooting_manual.json` — structured KB by module and error code

## Example Prompts
- "Payment timeouts — diagnose and give step-by-step fix."
- "Error ERR5001 observed in Database Layer, what should we do?"
- "Show last 5 CRITICAL logs for Payment Gateway and propose actions."
- "Summarize recurring issues this week and preventive steps."

## Notes
- Index is persisted under `.store/kb_index/` and `.store/memory_index/`.
- You can extend `data/` and rerun `build_index.py` at any time.
