from typing import List
from langchain.agents import create_react_agent, AgentExecutor
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.memory import ConversationBufferMemory, VectorStoreRetrieverMemory

from config import settings
from llm import make_llm
from tools import TOOLS

def make_memory():
    # Long-term memory as vector memory
    embeddings = HuggingFaceEmbeddings(model_name=settings.embedding_model)
    try:
        vs = FAISS.load_local(settings.memory_store_dir, embeddings, allow_dangerous_deserialization=True)
    except Exception:
        vs = FAISS.from_texts(["System memory initialized."], embedding=embeddings)
        vs.save_local(settings.memory_store_dir)
    retriever = vs.as_retriever(search_kwargs={"k": 4})
    long_term = VectorStoreRetrieverMemory(retriever=retriever, memory_key="history")
    # Short-term buffer memory
    short_term = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    return long_term, short_term, vs

def make_agent():
    llm = make_llm()
    long_mem, short_mem, memory_store = make_memory()

    # ReAct prompt instructing tool usage + RAG
    prompt = ChatPromptTemplate.from_messages([
        ("system",
         "You are a senior SRE/Support engineer for a Banking Management System. "
         "Use tools when helpful. Prefer citing error codes and stepwise runbooks. "
         "If user reports a symptom, retrieve related KB and propose diagnostics + resolution."
        ),
        ("human", "{input}"),
        ("ai", "Before answering, think which tool can help: retrieve_kb, manual_by_error, filter_logs. "
               "If you used tools, summarize findings and give concise actionable steps.")
    ])

    # Build agent
    agent = create_react_agent(llm=llm, tools=TOOLS, prompt=prompt)
    executor = AgentExecutor(
        agent=agent,
        tools=TOOLS,
        verbose=True,
        memory=short_mem,  # Agent-level short-term memory
        handle_parsing_errors=True,
    )

    # Wrap with simple object to expose memory store for saving long-term notes
    class AgentWithMemory:
        def __init__(self, exec, long_term, vs):
            self.exec = exec
            self.long_term = long_term
            self.vs = vs
        def aask(self, query: str):
            # Not using async; keep API consistent
            return self.exec.invoke({"input": query})
        def remember(self, note: str):
            self.vs.add_texts([note])
            self.vs.save_local(settings.memory_store_dir)
            return "Noted."
    return AgentWithMemory(executor, long_mem, memory_store)

if __name__ == "__main__":
    agent = make_agent()
    print(agent.aask("Hello, what can you do?"))
