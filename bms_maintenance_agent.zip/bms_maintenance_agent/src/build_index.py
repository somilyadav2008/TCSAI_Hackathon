import json
import pandas as pd
from pathlib import Path
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from config import settings

def load_documents():
    data_dir = Path(settings.data_dir)
    docs = []

    # Troubleshooting manual JSON -> many docs
    manual = json.loads((data_dir / "troubleshooting_manual.json").read_text(encoding="utf-8"))
    for module, entry in manual.get("modules", {}).items():
        for issue in entry.get("issues", []):
            content = []
            content.append(f"Module: {module}")
            content.append(f"Error Code: {issue['error_code']}")
            content.append(f"Title: {issue['title']}")
            content.append("Causes:\n- " + "\n- ".join(issue.get("causes", [])))
            content.append("Diagnostics:\n- " + "\n- ".join(issue.get("diagnostics", [])))
            content.append("Resolution:\n- " + "\n- ".join(issue.get("resolution", [])))
            if issue.get("runbooks"):
                content.append("Runbooks:\n- " + "\n- ".join(issue["runbooks"]))
            if issue.get("metrics_to_watch"):
                content.append("Metrics:\n- " + "\n- ".join(issue["metrics_to_watch"]))
            text = "\n\n".join(content)
            docs.append(Document(
                page_content=text,
                metadata={"module": module, "error_code": issue['error_code'], "title": issue['title'], "type": "manual"}
            ))

    # Logs CSV -> smaller docs (grouped by error code or module chunks if needed)
    logs = pd.read_csv(data_dir / "maintenance_logs.csv")
    # Chunk by 25 rows per doc for context
    chunk_size = 25
    for i in range(0, len(logs), chunk_size):
        subset = logs.iloc[i:i+chunk_size]
        text = subset.to_csv(index=False)
        docs.append(Document(
            page_content=f"LOG CHUNK:\n{subset.to_csv(index=False)}",
            metadata={"type": "logs", "chunk": i // chunk_size}
        ))

    # Issues CSV -> one doc
    issues = pd.read_csv(data_dir / "sample_issues.csv")
    docs.append(Document(
        page_content=f"ISSUES:\n{issues.to_csv(index=False)}",
        metadata={"type": "issues"}
    ))

    return docs

def main():
    embeddings = HuggingFaceEmbeddings(model_name=settings.embedding_model)
    docs = load_documents()
    vs = FAISS.from_documents(docs, embedding=embeddings)
    Path(settings.kb_store_dir).mkdir(parents=True, exist_ok=True)
    vs.save_local(settings.kb_store_dir)
    print(f"Built KB index with {len(docs)} docs at {settings.kb_store_dir}")

if __name__ == "__main__":
    main()
