import json
from datetime import datetime
from pathlib import Path
import pandas as pd
from typing import Optional, List, Dict, Any

from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain.tools import Tool

from config import settings

DATA_DIR = Path(settings.data_dir)

# Preload data
LOGS = pd.read_csv(DATA_DIR / "maintenance_logs.csv")
MANUAL = json.loads((DATA_DIR / "troubleshooting_manual.json").read_text(encoding="utf-8"))

# Vector store for KB
def _load_kb_vectorstore():
    embeddings = HuggingFaceEmbeddings(model_name=settings.embedding_model)
    vs = FAISS.load_local(settings.kb_store_dir, embeddings, allow_dangerous_deserialization=True)
    return vs

def retrieve_kb(query: str, k: int = 6) -> str:
    vs = _load_kb_vectorstore()
    docs = vs.similarity_search(query, k=k)
    out = []
    for i, d in enumerate(docs, 1):
        out.append(f"[{i}] METADATA={d.metadata}\n{d.page_content[:1200]}")
    return "\n\n".join(out)

def manual_by_error(error_code: str) -> str:
    for module, entry in MANUAL.get("modules", {}).items():
        for issue in entry.get("issues", []):
            if issue.get("error_code") == error_code:
                return json.dumps({"module": module, **issue}, indent=2)
    return f"No manual entry found for {error_code}"

def filter_logs(module: Optional[str] = None, error_code: Optional[str] = None,
                severity: Optional[str] = None, limit: int = 20) -> str:
    df = LOGS.copy()
    if module:
        df = df[df["module"].str.contains(module, case=False, na=False)]
    if error_code:
        df = df[df["error_code"] == error_code]
    if severity:
        df = df[df["severity"].str.upper() == severity.upper()]
    df = df.sort_values("timestamp", ascending=False).head(limit)
    return df.to_csv(index=False)

TOOLS = [
    Tool.from_function(
        func=retrieve_kb,
        name="retrieve_kb",
        description="Semantic search over the KB/logs/issues. Input: natural language query. Output: top matching snippets."
    ),
    Tool.from_function(
        func=manual_by_error,
        name="manual_by_error",
        description="Lookup troubleshooting manual by error code (e.g., ERR5001). Returns JSON."
    ),
    Tool.from_function(
        func=filter_logs,
        name="filter_logs",
        description="Filter recent logs by optional module, error_code, severity, limit. Returns CSV."
    ),
]
