from typing import Literal
from config import settings

# LLM constructors are separated to keep deps optional
def make_llm():
    if settings.provider.lower() == "openai":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=settings.openai_model, temperature=0.2)
    elif settings.provider.lower() == "ollama":
        from langchain_community.chat_models import ChatOllama
        return ChatOllama(model=settings.ollama_model, temperature=0.2)
    else:
        raise ValueError("Unknown PROVIDER. Use 'openai' or 'ollama'.")
